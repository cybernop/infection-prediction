import requests
import pandas as pd
import io
import argparse
import os
import boto3

def parse_arguments():
    parser = argparse.ArgumentParser()
    code_path = os.path.dirname(os.path.realpath(__file__))
    parser.add_argument('--api-url',
                        dest='api_url', default='https://opendata.arcgis.com/datasets/dd4580c810204019a7b8eb3e0b329dd6_0.geojson')
    parser.add_argument('--output-file-path',
                        dest='output_file_path', default='./rki_data.csv')
    parser.add_argument('--output-bucket',
                        dest='output_bucket', default=None)
    parser.add_argument('--output-key',
                        dest='output_key', default=None)
    parser.add_argument('--output-mode',
                        dest='output_mode', choices=['s3', 'local'], default='local')
    args = parser.parse_args()

    dict_args_values = {}

    dict_args_values['api_url'] = args.api_url
    dict_args_values['output_file_path'] = args.output_file_path
    dict_args_values['output_bucket'] = args.output_bucket
    dict_args_values['output_key'] = args.output_key
    dict_args_values['output_mode'] = args.output_mode

    return dict_args_values


def get_data_from_api(url):
    API_URL = url
    headers = {
        'Content-Type': 'application/json',
    }
    print(url)
    response = requests.get(url, headers=headers)
    return response

def parse_api_data(data):

    list_features = data['features']
    list_feature_properties = [feature['properties'] for feature in list_features]

    return list_feature_properties


def write_data(dataframe, write_mode, output_file_path=None, output_bucket=None, output_key=None):

    if write_mode == 'local':
        dataframe.to_csv(output_file_path, index=False, sep=";")

    elif write_mode == 's3':
        string_buf = io.StringIO()
        dataframe.to_csv(string_buf, index=False, sep=";")
        string_buf.seek(0)
        bytes_content = string_buf.read()

        bytes_buf = io.BytesIO(bytes_content.encode('utf-8'))
        s3 = boto3.client('s3')
        s3.upload_fileobj(bytes_buf, output_bucket, output_key)

    return


def main():
    dict_args_values = parse_arguments()

    api_url = dict_args_values.get('api_url')
    output_file_path = dict_args_values.get('output_file_path')
    output_bucket = dict_args_values.get('output_bucket')
    output_key = dict_args_values.get('output_key')
    output_mode = dict_args_values.get('output_mode')

    response = get_data_from_api(api_url)

    parsed_data = parse_api_data(response.json())

    df = pd.DataFrame(parsed_data)

    write_data(df, output_mode, output_file_path, output_bucket, output_key)

if __name__ == '__main__':
    main()
