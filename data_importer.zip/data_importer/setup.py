import os
import setuptools
from distutils.core import setup

setup(
    name='rki_corona_dataimporter',
    version='0.0.1',
    packages=setuptools.find_packages(),
    url='',
    license='',
    author='tahakhan',
    author_email='m.taha.khan@hotmail.com',
    description='',
    install_requires=[
              'pandas>=0.25.3',
              'argparse>=1.4.0',
              'boto3'
          ]
)
